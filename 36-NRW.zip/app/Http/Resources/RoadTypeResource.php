<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Support\Facades\Crypt;

class RoadTypeResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'id'=>Crypt::encrypt($this->id),
            'lable_name'=>$this->lable_name,
            'vph'=>$this->vph,
            'vphpl'=>$this->vphpl,
        ];
    }
}
